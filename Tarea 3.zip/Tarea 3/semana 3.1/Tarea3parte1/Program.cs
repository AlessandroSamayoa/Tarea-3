﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea3parte1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exercise = true;
            while (exercise)
            {
                Console.WriteLine("Escriba el número de ejercicio que desee revisar y presione Enter acontinuación");
                Console.WriteLine("1.Ejercicio 1\n2.Ejercicio 2\n3.Ejercicio 3\n4.Ejercicio 4\n5.Ejercicio 5");
                Console.WriteLine("6.Ejercicio 6\n7.Ejercicio 7\n8.Ejercicio 8\n9.Ejercicio 9\n10.Ejercicio 10\n11. Salir");
                int selec = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (selec)
                {
                    
                    case 1:
                        //Ejercicio 1.
                        int num1, num2;
                        Console.WriteLine("Ejercicio 1\nPrograma que acepta dos numeros enteros, y comprueba si son iguales o no\nEscriba el primer número");
                        num1 = int.Parse(Console.ReadLine());
                        Console.WriteLine("Ingrese el segundo número");
                        num2 = int.Parse(Console.ReadLine());
                        if (num2 == num1)
                        {
                            Console.WriteLine("Son igual");
                        }
                        else
                        {
                            Console.WriteLine("{0} no es igual a {1}", num1, num2);
                        }
                        Console.WriteLine("Presione cualquier letra para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 2:
                        //Ejercicio 2.
                        Console.WriteLine("Ejercicio 2\nEscriba el número para ver si es par o impar, luego de eso, presione Enter para continuar");
                        int nume1 = int.Parse(Console.ReadLine());
                        if (nume1 % 2 == 0)
                        {
                            Console.WriteLine("{0} es par", nume1);
                        }
                        else
                        {
                            Console.WriteLine("Es impar");
                        }
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadLine();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 3:
                        //Ejercicio 3.
                        Console.WriteLine("Ejercicio 3\nEscriba el número para determinar si es positivo o negativo\nPresione Enter para continuar");
                        int pn = int.Parse(Console.ReadLine());
                        if (pn >= 0)
                        {
                           Console.WriteLine("Es positivo");
                        }
                        else
                        {
                           Console.WriteLine("Es negativo");
                        }
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;
                        
                    case 4:
                        //Ejercicio 4.
                        Console.WriteLine("Ejercicio 4\nEscriba el año que desee para saber si es bisiesto o no");
                        int año = int.Parse(Console.ReadLine());
                        if (año % 4 == 0)
                        {
                            Console.WriteLine("El año {0} es año bisiesto", año);
                        }
                        else
                        {
                            Console.WriteLine("el año {0} no es año bisiesto", año);
                        }
                        Console.WriteLine("Presione cualquier letra para continuar");
                        Console.ReadLine();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 5:
                        //Ejercicio 5.
                        bool sweje5 = true;
                        while (sweje5)
                        {
                            Console.WriteLine("Ejercicio 5\nEscriba su edad para ver si es elegible para emitir su voto");
                            int edad = int.Parse(Console.ReadLine());
                            if (edad > 17 && edad < 101)
                            {
                                Console.WriteLine("Felicitaciones, usted puede votar");
                                sweje5 = false;
                            }
                            else
                            {
                                if (edad > 100)
                                {
                                    Console.WriteLine("Escribio mal su edad, no puede tener demasiados años");
                                    Console.WriteLine("Presione Enter para regresar");
                                    while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                                    Console.Clear();
                                    sweje5 = true;
                                }
                                else
                                {
                                    Console.WriteLine("Usted es menor de edad, no puede votar");
                                    sweje5 = false;
                                }
                            }
                        }
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 6:
                        //Ejercicio 6.
                        bool estej6 = true;
                        while (estej6)
                        {
                            Console.WriteLine("Ejercicio 6\nEscriba la estatura en centimetros, acontinuación de eso presione Enter\ny vera si es de estatura baja o alta");
                            int estatura = int.Parse(Console.ReadLine());
                            if (estatura > 169 && estatura < 223)
                            {
                                Console.WriteLine("La persona es de altura alta");
                                estej6 = false;
                            }
                            else
                            {
                                if (estatura > 222 || estatura < 50)
                                {
                                    Console.WriteLine("Escriba bien su estatura por favor\nPresione Enter para regresar");
                                    while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                                    Console.Clear();
                                    estej6 = true;
                                }
                                else
                                {
                                    Console.WriteLine("La persona es de estatura baja");
                                    estej6 = false;
                                }
                            }
                        }
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 7:
                        //Ejercicio 7.
                        Console.WriteLine("Ejercicio 7\nEscriba 3 números y se encontrara el mayor de lo tres números");
                        int n1, n2, n3;
                        Console.WriteLine("Escriba el primer número");
                        n1 = int.Parse(Console.ReadLine());
                        Console.WriteLine("Escriba el segundo número");
                        n2 = int.Parse(Console.ReadLine());
                        Console.WriteLine("Escriba el tercer número");
                        n3 = int.Parse(Console.ReadLine());
                        if (n1 > n2 && n1 > n3)
                        {
                            Console.WriteLine("El primer número es el mayor de los tres");
                        }
                        else
                        {
                            if (n2 > n1 && n2 > n3)
                            {
                                Console.WriteLine("El segundo número es el mayor de los tres");
                            }
                            else
                            {
                                if (n3 > n1 && n3 > n2)
                                {
                                    Console.WriteLine("El tercer número es el mayor de los tres");
                                }
                                else
                                {
                                    if (n1 == n2 && n2 > n3)
                                    {
                                        Console.WriteLine("El primer y segundo número son iguales, son mayores que el tercero");
                                    }
                                    else
                                    {
                                        if (n2 == n3 && n2 > n1)
                                        {
                                            Console.WriteLine("El segundo y tercer número son iguales, son mayores que el primero");
                                        }
                                        else
                                        {
                                            if (n1 == n3 && n3 > n2)
                                            {
                                                Console.WriteLine("El primer y tercer número son iguales, son mayores que el segundo");
                                            }
                                            else
                                            {
                                                Console.WriteLine("Los tres números son iguales");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 8:
                        //Ejercicio 8.
                        bool notas = true;
                        int cod, fi, qui, pro;
                        while (notas)
                        {
                            Console.WriteLine("Ejercicio 8\nEscriba su nombre, su codigo para entrar a su cuenta, no olvide escribir su nombre con mayúscula");

                            Console.WriteLine("Escriba su código");
                            cod = int.Parse(Console.ReadLine());
                            Console.WriteLine("Escriba su nombre");
                            string nombre1 = Console.ReadLine();


                            if (cod == 1001 && nombre1 == "Juan" || cod == 1002 && nombre1 == "Pedro" || cod == 1003 && nombre1 == "Kyle" ||
                                cod == 1004 && nombre1 == "Lucas" || cod == 1005 && nombre1 == "Alessandra")
                            {
                                Console.WriteLine("Bienvenido a su cuenta {0}, presione Enter para continuar", nombre1);
                                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                                Console.Clear();
                                Console.WriteLine("Sin rodar: {0}", cod);
                                Console.WriteLine("Nombre del estudiante: {0}", nombre1);
                                notas = false;
                            }
                            else
                            {
                                Console.WriteLine("Escriba bien su nombre o su contraseña, presione cualquier tecla para regresar");
                                Console.ReadKey();
                                Console.Clear();
                                notas = true;
                            }
                        }
                        bool notas1 = true;
                        while (notas1)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Escriba la nota de física");
                            fi = int.Parse(Console.ReadLine());
                            Console.WriteLine("Escriba la nota de química");
                            qui = int.Parse(Console.ReadLine());
                            Console.WriteLine("Escriba la nota de programación");
                            pro = int.Parse(Console.ReadLine());

                            if (fi < 101 && qui < 101 && pro < 101)
                            {
                                int ntotal, nprom;
                                ntotal = fi + qui + pro;
                                nprom = ntotal / 3;
                                Console.WriteLine("Nota en Física: {0}", fi);
                                Console.WriteLine("Nota en Química: {0}", qui);
                                Console.WriteLine("Nota en Programacion: {0}", pro);
                                Console.WriteLine("Nota Total = {0}", ntotal);
                                Console.WriteLine("Promedio = {0}", nprom);
                                Console.WriteLine("Presione cualquier letra para continuar");
                                Console.ReadKey();
                                Console.Clear();
                                notas1 = false;
                            }
                            else
                            {
                                Console.WriteLine("Escriba bien sus notas");
                                notas1 = true;
                            }
                        }
                        selec = 0;
                        exercise = true;
                        break;




                    case 9:
                        //Ejercicio 9.
                        bool clima = true;
                        while (clima)
                        {
                            Console.WriteLine("Ejercicio 9");
                            Console.WriteLine("Ingrese la temperatura en grados centígrados, acontinuación le mostrara un mensaje adecuado");
                            Console.WriteLine("de acuerdo con el estado de temperatura");
                            int temp = int.Parse(Console.ReadLine());
                            //Temperaturas registradas.
                            if (temp < -89 || temp > 58)
                            {
                                Console.WriteLine("La temperatura es muy alta o muy baja\nPresione Enter para repetir");
                                while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                                Console.Clear();
                                clima = true;

                            }
                            else
                            {
                                if (temp < 0)
                                {
                                    Console.WriteLine("El clima está para congelarse");
                                    clima = false;
                                }
                                else
                                {
                                    if (temp < 10)
                                    {
                                        Console.WriteLine("El clima está muy frío");
                                        clima = false;
                                    }
                                    else
                                    {
                                        if (temp < 20)
                                        {
                                            Console.WriteLine("El clima está frío");
                                            clima = false;
                                        }
                                        else
                                        {
                                            if (temp < 30)
                                            {
                                                Console.WriteLine("El clima es normal");
                                                clima = false;
                                            }
                                            else
                                            {
                                                if (temp < 40)
                                                {
                                                    Console.WriteLine("El clima está caliente");
                                                    clima = false;
                                                }
                                                else
                                                {
                                                    Console.WriteLine("El clima está muy caliente");
                                                    clima = false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Console.WriteLine("Presione cualquier letra para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 10:
                        //Ejercicio 10.
                        bool let = true;
                        while (let)
                        {
                            Console.WriteLine("Ejercicio 10\nEscriba cualquier letra del abecedario para saber si es vocal o consonante");
                            char l;

                            l = Convert.ToChar(Console.ReadLine());
                            if (char.ToLower(l) == 'a' ||
                                char.ToLower(l) == 'e' ||
                                char.ToLower(l) == 'i' ||
                                char.ToLower(l) == 'o' ||
                                char.ToLower(l) == 'u')
                            {
                                Console.WriteLine("La letra es una vocal");
                                let = false;
                            }
                            else
                            {
                                if (char.IsLetter(l))
                                {
                                    Console.WriteLine("La letra es una consonante");
                                    let = false;
                                }
                                else
                                {
                                    Console.WriteLine("'{0}' no es vocal, ni consonante\nPresione Enter e intente de nuevo", l);
                                    while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                                    Console.Clear();
                                    let = true;
                                }
                            }
                        }
                        Console.WriteLine("Presione cualquier letra para continuar");
                        Console.ReadKey();
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;

                    case 11:
                        //salir.
                        Console.WriteLine("¿Estás seguro qué deseas Salir?\n1.Si\n2.No\nPresione Enter después de su selección");
                        int salir = int.Parse(Console.ReadLine());
                        switch (salir)
                        {
                            case 1:
                                exercise = false;
                                break;
                            case 2:
                                Console.Clear();
                                selec = 0;
                                exercise = true;
                                break;
                            default:
                                Console.WriteLine("Número incorrecto, presione Enter para regresar a la pantalla inicial");
                                while (Console.ReadKey().Key != ConsoleKey.Enter) ;
                                Console.Clear();
                                selec = 0;
                                exercise = true;
                                break;
                        }
                        break;

                    default:
                        Console.WriteLine("Selección invalida\nPresione Enter para regresar al Menú de inicio");
                        while (Console.ReadKey().Key != ConsoleKey.Enter) { }
                        Console.Clear();
                        selec = 0;
                        exercise = true;
                        break;
                }
            }



        }
    }
}
